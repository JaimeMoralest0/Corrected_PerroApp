package com.example.perroapp.api

import com.example.perroapp.model.Dog
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("breeds") // Endpoint para obtener la lista de razas de perros
    suspend fun getBreeds(
        @Query("api_key") apiKey: String
    ): List<Dog>
}
