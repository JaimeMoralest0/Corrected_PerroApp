package com.example.perroapp.model

data class DogResponse(
    val message: List<String>,
    val status: String
)
